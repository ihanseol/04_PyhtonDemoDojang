from mcp_kakao_local.server import mcp


def main():
  mcp.run()


if __name__ == "__main__":
  main()
