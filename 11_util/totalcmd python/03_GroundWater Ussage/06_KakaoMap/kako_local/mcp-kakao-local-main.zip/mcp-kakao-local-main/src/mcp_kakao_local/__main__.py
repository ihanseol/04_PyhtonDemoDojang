from mcp_kakao_local import main

if __name__ == "__main__":
  main()
